    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package recursion;

    import java.util.ArrayList;

    /**
     *
     * @author Karunakar Reddy Katasani
     */
    public class RecursionDriver {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
            Recursion con = new Recursion();

            System.out.println("Sum of odd " + con.sumOfOdd(12));

            ArrayList<Student> a = new ArrayList<Student>();
            Student q = new Student("Adam");
            Student w = new Student("Bob");
            Student e = new Student("Charlie");
            Student r = new Student("David");
            Student t = new Student("Elfie");
            a.add(q);
            a.add(w);
            a.add(e);
            a.add(r);
            a.add(t);

            ArrayList<Student> b = new ArrayList<>(a);

            for (ArrayList<Student> stud : con.organizeSeats(a)) {
                System.out.println(stud);

            }

            System.out.println("**************Restricted Arrangement**************");

            for (ArrayList<Student> stud : con.organizeSeats(b, w, e, b.size())) {
                System.out.println(stud);

            }

            System.out.println(con.evaluateExpression("(1+2)"));
            System.out.println(con.evaluateExpression("(1+3)/(2%5)"));
            System.out.println(con.evaluateExpression("((2+4)*((3*2)-(2/4)+(9%4)))"));
            System.out.println(con.evaluateExpression("(2+4)/((7/3)+(2*4))+(8*4)/((9-2)-(-8*9))"));
            System.out.println(con.evaluateExpression("(3-1)/((3%3)/(-3*4)+(-7/6)%(-9/5))"));

        }

    }
