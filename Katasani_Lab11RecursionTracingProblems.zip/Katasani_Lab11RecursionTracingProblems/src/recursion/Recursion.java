    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package recursion;

    import java.util.ArrayList;

    /**
     *
     * @author Karunakar reddy Katasani
     */
    public class Recursion {

        public int sumOfOdd(int n) {
            if (n <= 0) {
                return 0;
            }
            if (n % 2 != 0) {
                return (n + sumOfOdd(n - 1));
            } else {
                return sumOfOdd(n - 1);
            }
        }

        public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList) {
            if (studentList.isEmpty()) {
                ArrayList<ArrayList<Student>> res = new ArrayList<>();
                res.add(new ArrayList<>());
                return res;
            }
            ArrayList<ArrayList<Student>> value = new ArrayList<>();
            Student first = studentList.remove(0);
            ArrayList<ArrayList<Student>> per = organizeSeats(studentList);
            for (ArrayList<Student> sm : per) {
                for (int i = 0; i <= sm.size(); i++) {
                    ArrayList<Student> q = new ArrayList<>(sm);
                    q.add(i, first);
                    value.add(q);
                }
            }

            return value;
        }

        public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList, Student student1, Student student2, int size) {

            if (studentList.isEmpty()) {
                ArrayList<ArrayList<Student>> result = new ArrayList<>();
                result.add(new ArrayList<>());
                return result;
            }
            ArrayList<ArrayList<Student>> returnValue = new ArrayList<>();
            Student firstElement = studentList.remove(0);

            ArrayList<ArrayList<Student>> permutations = organizeSeats(studentList, student1, student2, size);

            for (ArrayList<Student> smallerPermutated : permutations) {
                for (int index = 0; index <= smallerPermutated.size(); index++) {
                    ArrayList<Student> temp = new ArrayList<>(smallerPermutated);
                    temp.add(index, firstElement);

                    returnValue.add(temp);
                }
            }

            if (returnValue.get(0).size() == size) {
                int j = 0;
                while (j < returnValue.size()) {

                    for (int i = 0; i < returnValue.get(j).size() - 1; i++) {
                        if ((returnValue.get(j).get(i).equals(student1) && returnValue.get(j).get(i + 1).equals(student2))
                                || (returnValue.get(j).get(i).equals(student2) && returnValue.get(j).get(i + 1).equals(student1))) {
                            returnValue.remove(j);
                            j = 0;
                            break;

                        }

                    }
                    j++;

                }

            }

            return returnValue;
        }

        public double evaluateExpression(String str) {

            if (!str.contains("+") && !str.contains("*") && !str.contains("/") && !str.contains("%")) {
                if ((!str.contains("-") || str.indexOf("-") == str.lastIndexOf("-")) && (str.indexOf("-") == -1 || str.indexOf("-") == 0)) {
                    return Double.parseDouble(str);
                }
            }

            while (str.indexOf(")") != -1) {
                int Brace1 = str.indexOf(")");
                if (Brace1 != -1) {
                    int Brace2 = str.substring(0, Brace1).lastIndexOf("(");

                    if (Brace2 != -1) {

                        String l = str.substring(0, Brace2);
                        String m = str.substring(Brace2 + 1, Brace1);
                        String r = str.substring(Brace1 + 1, str.length());

                        if (l.length() == 0 && r.length() == 0) {
                            return evaluateExpression(m);
                        } else {
                            str = l+ evaluateExpression(m) + r;
                        }
                    }

                }
            }
            str = str.replaceAll("--", "+");
            int i;
            for (i = str.length() - 1; i >= 0; i--) {
                if (str.charAt(i) == '+') {
                    break;
                } else if (str.charAt(i) == '-' && i > 0) {
                    if (!(str.charAt(i - 1) == '+' || str.charAt(i - 1) == '*' || str.charAt(i - 1) == '/' || str.charAt(i - 1) == '%' || str.charAt(i - 1) == '(')) {
                        break;
                    }
                }
            }
            if (i < 0) {
                for (i = str.length() - 1; i >= 0; i--) {
                    if (str.charAt(i) == '*' || str.charAt(i) == '/' || str.charAt(i) == '%') {
                        break;
                    }
                }
            }

            if (i < 0) {
                return evaluateExpression(str);
            }

            String a1 = str.substring(0, i);
            String a2 = str.substring(i + 1, str.length());

            if (a1.length() == 0 && a2.length() > 0) {
                return evaluateExpression(a2);
            } else if (a2.length() == 0 && a1.length() > 0) {
                return evaluateExpression(a1);
            } else if (a1.length() == 0 && a2.length() == 0) {
                return 0;
            }
            double result = 0;

            switch (str.charAt(i)) {
                case '+':
                    result = evaluateExpression(a1) + evaluateExpression(a2);
                    break;
                case '-':
                    result = evaluateExpression(a1) - evaluateExpression(a2);
                    break;
                case '%':
                    result = evaluateExpression(a1) % evaluateExpression(a2);
                    break;
                case '*':
                    result = evaluateExpression(a1) * evaluateExpression(a2);
                    break;
                case '/':
                    double r1 = evaluateExpression(a2);
                    if (r1 == 0) {
                        System.out.println("Invalid divisor");
                        System.exit(1);
                    } else {
                        result = evaluateExpression(a1) / r1;
                    }
                    break;
            }
            return result;

        }
    }
